#!/system/bin/sh

# 等待Magisk完全启动
while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
done

block_sleep_and_curl() {
    while true; do
        pids_sleep=$(pidof sleep)
        if [ -n "$pids_sleep" ]; then
            for pid in $pids_sleep; do
                kill -9 $pid
            done
        fi

        pids_curl=$(pidof curl)
        if [ -n "$pids_curl" ]; then
            for pid in $pids_curl; do
                kill -9 $pid
            done
        fi

        sleep 0.1
    done
}

block_sleep_and_curl &
